import React, { useState } from 'react';
import { Source } from '../../lib/types';

interface SourcesDisplayProps {
  sources: Source[];
  retrievalIntent?: string;
}

export default function SourcesDisplay({ sources, retrievalIntent }: SourcesDisplayProps) {
  const [isExpanded, setIsExpanded] = useState(true);
  const [showRelatedConnectionSources, setShowRelatedConnectionSources] = useState(false);
  const vaultName = 'Michel';
  const vaultRoot = '/Users/michel/Library/Mobile Documents/iCloud~md~obsidian/Documents/Michel';
  const hasUnsafeScheme = (value: string) => /^(javascript|data|vbscript):/i.test(value.trim());
  const hasWebScheme = (value: string) => /^https?:\/\//i.test(value.trim());
  const sourceTypeLabels: Record<string, string> = {
    'linked-note': 'Linked note',
    'direct-excerpt': 'Excerpt',
    'entity-context': 'Entity',
    'web-result': 'Web',
  };

  if (!sources || sources.length === 0) {
    return null;
  }

  const isConnectionView = retrievalIntent === 'connection';
  const isExplicitPathSource = (source: Source) =>
    /explicit graph path/i.test(source.snippet || '') || source.relevance > 72;
  const primarySources = isConnectionView
    ? sources.filter((source) => isExplicitPathSource(source))
    : sources;
  const secondarySources = isConnectionView
    ? sources.filter((source) => !isExplicitPathSource(source))
    : [];

  const categorizeSource = (source: Source) => {
    if (source.sourceCategory) return source.sourceCategory;
    const filepath = source.filepath?.trim() || '';
    return hasWebScheme(filepath) ? 'web' : 'vault';
  };

  const partitionSources = (items: Source[]) => ({
    vault: items.filter((source) => categorizeSource(source) === 'vault'),
    web: items.filter((source) => categorizeSource(source) === 'web'),
  });

  const sourceCardKey = (source: Source, idx: number) =>
    `${categorizeSource(source)}:${source.sourceType || 'unknown'}:${source.filepath || source.filename || 'unknown'}:${idx}`;

  const renderSourceCard = (source: Source, idx: number) => (
    <div className="bg-[#1C1C1E] border border-[#2C2C2E] rounded-lg p-3 text-sm">
      <div className="flex items-start justify-between mb-2">
        <div className="font-medium text-white flex items-center gap-2 flex-wrap">
          <span className="text-white/40">{idx + 1}.</span>
          {(() => {
            const link = buildSourceLink(source);
            if (!link) return <span>{source.filename}</span>;
            return (
              <a
                href={link}
                className="text-[#0A84FF] hover:text-[#6AB7FF] underline underline-offset-2"
                title={categorizeSource(source) === 'web' ? 'Open web source' : 'Open in Obsidian'}
                target={categorizeSource(source) === 'web' ? '_blank' : undefined}
                rel={categorizeSource(source) === 'web' ? 'noreferrer' : undefined}
              >
                {safeFilename(source)}
              </a>
            );
          })()}
          {source.sourceType && sourceTypeLabels[source.sourceType] && (
            <span className="px-2 py-0.5 rounded-full border border-white/10 text-[10px] uppercase tracking-[0.12em] text-white/45">
              {sourceTypeLabels[source.sourceType]}
            </span>
          )}
        </div>
        <span className="text-[#0A84FF] font-mono text-xs">
          {(Number.isFinite(source.relevance) ? source.relevance : 50).toFixed(0)}%
        </span>
      </div>
      {source.filepath && (
        <div className="text-xs text-white/40 mb-2 font-mono truncate">
          {source.filepath}
        </div>
      )}
      <div className="text-xs text-white/60 line-clamp-3">{source.snippet}</div>
    </div>
  );

  const buildSourceLink = (source: Source) => {
    const filepath = source.filepath?.trim();
    if (filepath) {
      if (hasUnsafeScheme(filepath)) {
        return null;
      }
      if (hasWebScheme(filepath)) {
        return filepath;
      }
      const looksAbsolute = filepath.startsWith('/') || /^[A-Za-z]:[\\/]/.test(filepath);
      if (looksAbsolute) {
        if (filepath.startsWith(vaultRoot)) {
          const relPath = filepath.slice(vaultRoot.length).replace(/^\/+/, '');
          if (relPath) {
            return `obsidian://open?vault=${encodeURIComponent(vaultName)}&file=${encodeURIComponent(relPath)}`;
          }
        }
        return `obsidian://open?path=${encodeURIComponent(filepath)}`;
      }
      return `obsidian://open?vault=${encodeURIComponent(vaultName)}&file=${encodeURIComponent(filepath)}`;
    }
    const filename = source.filename?.trim();
    if (filename) {
      if (hasUnsafeScheme(filename)) {
        return null;
      }
      if (hasWebScheme(filename)) {
        return filename;
      }
      return `obsidian://search?vault=${encodeURIComponent(vaultName)}&query=${encodeURIComponent(filename)}`;
    }
    return null;
  };

  const safeFilename = (source: Source) => {
    if (source.filename?.trim()) return source.filename.trim();
    if (source.filepath?.trim()) return source.filepath.split('/').pop() || 'Unknown';
    return 'Unknown';
  };

  const renderSourceGroups = (items: Source[]) => {
    const groups = partitionSources(items);
    const sections = [
      { key: 'vault-sources', title: 'Vault Sources', items: groups.vault, offset: 0 },
      { key: 'web-sources', title: 'Web Sources', items: groups.web, offset: groups.vault.length },
    ].filter((section) => section.items.length > 0);

    if (sections.length === 0) {
      return null;
    }

    return (
      <div className="space-y-4">
        {sections.map((section) => {
          const visibleLimit = 6;
          const visibleItems = section.items.slice(0, visibleLimit);
          const hiddenCount = section.items.length - visibleItems.length;
          return (
          <div key={section.key} className="space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-[11px] font-semibold uppercase tracking-[0.16em] text-white/45">
                {section.title}
              </h4>
              <span className="text-[11px] font-mono text-white/30">{section.items.length}</span>
            </div>
            {visibleItems.map((source, idx) => (
              <div key={sourceCardKey(source, section.offset + idx)}>
                {renderSourceCard(source, section.offset + idx)}
              </div>
            ))}
            {hiddenCount > 0 && (
              <div className="text-xs text-white/40 italic">
                ... {hiddenCount} more
              </div>
            )}
          </div>
        )})}
      </div>
    );
  };

  return (
    <div className="mt-4 pt-4 border-t border-[#2C2C2E]">
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="w-full flex items-center justify-between text-sm font-medium text-white/60 hover:text-white transition-colors mb-3"
      >
        <span className="flex items-center gap-2">
          <span>📚</span>
          <span>Sources ({sources.length} documents)</span>
        </span>
        <svg
          className={`w-4 h-4 transition-transform ${isExpanded ? 'rotate-180' : ''}`}
          fill="none"
          viewBox="0 0 24 24"
          stroke="currentColor"
        >
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
        </svg>
      </button>

      {isExpanded && (
        <div className="space-y-3">
          {renderSourceGroups(primarySources)}

          {isConnectionView && secondarySources.length > 0 && (
            <div className="rounded-lg border border-[#2C2C2E] bg-[#14161A] overflow-hidden">
              <button
                onClick={() => setShowRelatedConnectionSources(!showRelatedConnectionSources)}
                className="w-full flex items-center justify-between px-3 py-2 text-xs font-medium text-white/55 hover:text-white transition-colors"
              >
                <span>Related but not on returned path ({secondarySources.length})</span>
                <svg
                  className={`w-4 h-4 transition-transform ${showRelatedConnectionSources ? 'rotate-180' : ''}`}
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>

              {showRelatedConnectionSources && (
                <div className="border-t border-[#2C2C2E] p-3">
                  {renderSourceGroups(secondarySources)}
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
